#include "abstract_List.h"
#include "Book.h"
#include "Book_management.h"
#include "Fiction.h"
#include "Lend_list.h"
#include "Non_Fiction.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <sstream>
#include <stdlib.h>

using namespace book;

vector<string> split(string s, string divid) {				//���ڿ� �и��ϴ� �Լ�
	vector<string> v;
	int start = 0;
	int d = s.find(divid);
	while (d != -1) {
		v.push_back(s.substr(start, d - start));
		start = d + 1;
		d = s.find(divid, start);
	}
	v.push_back(s.substr(start, d - start));

	return v;
}

int main() {
	Book_management book_management;
	Lend_list lend_list;
	Fiction fiction;
	Non_Fiction non_fiction;

	book_management.set_lend_list(lend_list);
	book_management.set_fiction(fiction);
	book_management.set_nonfiction(non_fiction);

	string line;
	ifstream file("bestsellers with categories.txt");
	if (file.is_open()) {
		getline(file, line);
		while (getline(file, line)) {
			vector<string> v = split(line, ",");
			vector<string>::iterator it = v.begin();
			Book* add_book = new Book;
			add_book->name = (*it);
			it++;
			add_book->author =(*it);
			it++;
			int price = atoi((*it).c_str());
			add_book->price = price;
			it++;
			int year = atoi((*it).c_str());
			add_book->year = year;
			it++;
			
			if ((*it) == "Fiction" || (*it) == "fiction") {
				add_book->genre = "fiction";
			}
			else {
				add_book->genre = "non_Fiction";
			}

			if (add_book->genre == "fiction") {
				fiction.add_book(add_book);
			}
			else {
				non_fiction.add_book(add_book);
			}
		}
	}
	else {
		cout << "Unable to open file";
		return 0;
	}
	cout << "���� ��� ������" << endl;


	while (true) {
		int num;
		cout << "\n\n";
		cout << "==========�������� �ý���==========" << endl;
		cout << "1. ��������" << endl;
		cout << "2. �����ݳ�" << endl;
		cout << "3. �����Ű��߰�" << endl;
		cout << "4. ������Ϻ���" << endl;
		cout << "5. ����ϱ�" << endl;
		cout << "===================================" << endl;
		cout << ">  ";
		cin >> num;


		if (num == 1) {
			cout << "\n";
			cout << "���������� �����մϴ�." << endl;
			cout << "\n";
			book_management.lend_book();
		}
		else if (num == 2) {
			cout << "\n";
			cout << "�����ݳ��� �����մϴ�." << endl;
			cout << "\n";
			book_management.return_book();
		}
		else if (num == 3) {
			book_management.add_book();
		}
		else if (num == 4) {
			cout << "\n";
			cout << "< ���� ��� >" << endl;
			book_management.show_booklist();
		}
		else if (num == 5) {
			cout << "�������� �ý����� �����մϴ�.";
			cout << "\n";
			break;
		}
	}
}
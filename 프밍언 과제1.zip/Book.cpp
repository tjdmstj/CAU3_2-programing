#include "Book.h"

namespace book {
	Book::Book() {					//������
		this->name = "";
		this->author = "";
		this->genre = "";
		this->price = 0;
		this->year = 0;
	}

	Book::~Book() {	}				//�Ҹ���

	void Book::set_name(string name) {
		this->name = name;
	}

	void Book::set_author(string author){
		this->author = author;
	}


	void Book::set_genre(string genre) {
		this->genre = genre;
	}

	void Book::set_price(int price) {
		this->price = price;
	}

	void Book::set_year(int year) {
		this->year = year;
	}
}
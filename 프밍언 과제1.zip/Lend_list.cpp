#include "Lend_list.h"

namespace book {
	Book* Lend_list::return_book() {
		string name;
		this->show_lendlist();
		cout << "� å�� �ݳ��Ͻðڽ��ϱ�?: ";
		cin >> name;
		return this->search(name);
	}

	void Lend_list::push_book(Book* book) {
		string name = book->name;
		lend_list.insert({ name, *book });
		cout << "  \"" << name << "\"" << "�� �����Ͽ����ϴ�." << endl;
	}

	Book* Lend_list::search(string name) {
		bool check = false;
		map<string, Book>::iterator it = this->lend_list.begin();
		while (it !=this->lend_list.end()) {
			if (name ==(*it).second.name) { 
				break; 
			}
			it++;
		}
		Book* return_book = new Book;

		return_book->name = (*it).second.name;
		return_book->author = (*it).second.author;
		return_book->genre = (*it).second.genre;
		return_book->price = (*it).second.price;
		return_book->year = (*it).second.year;
		lend_list.erase(it);
		return return_book;
	}


	void Lend_list::show_lendlist() {
		int i=1;
		map<string, Book>::iterator it = this->lend_list.begin();
		while (it != this->lend_list.end()) {
			Book* show = new Book;
			show->name = (*it).second.name;
			show->author = (*it).second.author;
			show->genre = (*it).second.genre;
			cout << "<" << i << ">" << endl;
			i++;
			cout <<"����: " << show->name << "\n����: " << show->author << "\n�帣: " << show->genre << endl;
			cout << "\n--------------------------------\n";
			free(show);
			it++;
		}
	}
}
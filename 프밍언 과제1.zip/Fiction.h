#pragma once
#include "abstract_List.h"

namespace book {
	class Fiction:public abstract_list{
		
	};
}
#include "Fiction.h"

namespace book {
	
}
#include "abstract_List.h"
#include <string>
#include <algorithm>


namespace book {
	Book* abstract_list::lend_book() {
		string name;
		this->show_booklist();
		cout << "� å�� �����ðڽ��ϱ�?(���� ���� �Է�): ";
		cin >> name;
		return this->search(name);
	}

	void abstract_list::add_book(Book* book) {
		this->booklist.push_back(*book);
	}

	Book* abstract_list::search(string name) {
		list<Book>::iterator it = booklist.begin();
		while (it != booklist.end())
		{	
			if (name == (*it).name)break;
			it++;
		}
		Book* return_book = new Book;
		return_book->author = (*it).author;
		return_book->genre = (*it).genre;
		return_book->name = (*it).name;
		return_book->price = (*it).price;
		return_book->year = (*it).year;
		booklist.erase(it);
		return return_book;
	}

	Book* abstract_list::search(int num) {
		list<Book>::iterator it = booklist.begin();
		for(int i=0;i<num;i++)
		{
			it++;
		}
		Book* return_book = new Book;
		return_book->author = (*it).author;
		return_book->genre = (*it).genre;
		return_book->name = (*it).name;
		return_book->price = (*it).price;
		return_book->year = (*it).year;
		booklist.erase(it);
		return return_book;
	}


void abstract_list::show_booklist() {
	int i = 1;
	list<Book>::iterator it = this->booklist.begin();
	while (it != this->booklist.end()) {
		Book* show = new Book;
		show->name = (*it).name;
		show->author = (*it).author;
		show->genre = (*it).genre;
		cout << "<" << i << ">" << endl;
		i++;
		cout <<"����: " << show->name << "\n����: " << show->author << "\n�帣: " << show->genre << endl;
		cout << "\n--------------------------------\n";
		free(show);
		it++;
	}
	}
	
}
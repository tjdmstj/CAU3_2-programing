#pragma once
#include "abstract_List.h"

namespace book {
	class Non_Fiction :public abstract_list {
		
	};
}
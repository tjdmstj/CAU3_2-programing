#pragma once
#include <iostream>
#include <string>
using namespace std;
namespace book {
	class Book {
	public:
		string name;
		string author;
		int price;				//����
		int year;				//�Ⱓ�⵵
		string genre;			//å�� �帣

		Book();					//������
		~Book();				//�Ҹ���
		void set_name(string);
		void set_author(string);
		void set_genre(string);
		void set_price(int);
		void set_year(int);
	};
}